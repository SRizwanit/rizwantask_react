/* dist-extension/ → .crx (Chrome, CRX3) + .zip (Firefox/Gecko-এ .xpi নামেও চলে) — কোনো বাইরের প্যাকেজ ছাড়া।
   স্থায়ী সাইনিং-কী: extension-key.pem (না থাকলে নতুন তৈরি হয়) — একই কী = একই এক্সটেনশন ID, তাই এটি সংরক্ষণ করুন, শেয়ার করবেন না। */
import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';
import crypto from 'node:crypto';

const dir = 'dist-extension', keyFile = 'extension-key.pem';
if (!fs.existsSync(dir + '/manifest.json')) { console.error('আগে `npm run build:ext` চালান'); process.exit(1); }

/* ---- ZIP (deflate) ---- */
const CRC = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
const crc32 = (b) => { let c = 0xffffffff; for (let i = 0; i < b.length; i++) c = CRC[(c ^ b[i]) & 255] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; };
function walk(d, base = '') { return fs.readdirSync(d, { withFileTypes: true }).flatMap((e) => e.isDirectory() ? walk(path.join(d, e.name), base + e.name + '/') : [base + e.name]).sort(); }
function makeZip(root) {
  const parts = [], cen = []; let off = 0;
  for (const name of walk(root)) {
    const data = fs.readFileSync(path.join(root, name)), def = zlib.deflateRawSync(data, { level: 9 });
    const useDef = def.length < data.length, body = useDef ? def : data, nm = Buffer.from(name), crc = crc32(data);
    const lh = Buffer.alloc(30); lh.writeUInt32LE(0x04034b50, 0); lh.writeUInt16LE(20, 4); lh.writeUInt16LE(0x0800, 6); lh.writeUInt16LE(useDef ? 8 : 0, 8);
    lh.writeUInt16LE(0, 10); lh.writeUInt16LE(0x21, 12); lh.writeUInt32LE(crc, 14); lh.writeUInt32LE(body.length, 18); lh.writeUInt32LE(data.length, 22); lh.writeUInt16LE(nm.length, 26);
    parts.push(lh, nm, body);
    const ch = Buffer.alloc(46); ch.writeUInt32LE(0x02014b50, 0); ch.writeUInt16LE(20, 4); ch.writeUInt16LE(20, 6); ch.writeUInt16LE(0x0800, 8); ch.writeUInt16LE(useDef ? 8 : 0, 10);
    ch.writeUInt16LE(0, 12); ch.writeUInt16LE(0x21, 14); ch.writeUInt32LE(crc, 16); ch.writeUInt32LE(body.length, 20); ch.writeUInt32LE(data.length, 24); ch.writeUInt16LE(nm.length, 28); ch.writeUInt32LE(off, 42);
    cen.push(ch, nm); off += 30 + nm.length + body.length;
  }
  const cd = Buffer.concat(cen), end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(cen.length / 2, 8); end.writeUInt16LE(cen.length / 2, 10); end.writeUInt32LE(cd.length, 12); end.writeUInt32LE(off, 16);
  return Buffer.concat([...parts, cd, end]);
}

/* ---- CRX3 ---- */
const varint = (n) => { const o = []; while (n > 127) { o.push((n & 127) | 128); n = Math.floor(n / 128); } o.push(n); return Buffer.from(o); };
const field = (tag, buf) => Buffer.concat([varint(tag), varint(buf.length), buf]);

if (!fs.existsSync(keyFile)) {
  fs.writeFileSync(keyFile, crypto.generateKeyPairSync('rsa', { modulusLength: 2048 }).privateKey.export({ type: 'pkcs8', format: 'pem' }));
  console.log('নতুন সাইনিং-কী তৈরি:', keyFile);
}
const priv = crypto.createPrivateKey(fs.readFileSync(keyFile));
const pub = crypto.createPublicKey(priv).export({ type: 'spki', format: 'der' });
const crxId = crypto.createHash('sha256').update(pub).digest().subarray(0, 16);
const zip = makeZip(dir);
const signedData = field(0x0a, crxId);                       // SignedData { crx_id = 1 }
const lenLE = Buffer.alloc(4); lenLE.writeUInt32LE(signedData.length);
const signature = crypto.sign('sha256', Buffer.concat([Buffer.from('CRX3 SignedData\0'), lenLE, signedData, zip]), priv);
const header = Buffer.concat([
  field(0x12, Buffer.concat([field(0x0a, pub), field(0x12, signature)])),   // sha256_with_rsa { public_key, signature }
  field(80002, signedData)                                                  // signed_header_data (10000)
]);
const pre = Buffer.alloc(12); pre.write('Cr24', 0); pre.writeUInt32LE(3, 4); pre.writeUInt32LE(header.length, 8);

const ver = JSON.parse(fs.readFileSync(dir + '/manifest.json', 'utf8')).version;
fs.mkdirSync('release', { recursive: true });
const base = `release/RizwanTask-${ver}`;
fs.writeFileSync(base + '.crx', Buffer.concat([pre, header, zip]));
fs.writeFileSync(base + '.zip', zip);
fs.copyFileSync(base + '.zip', base + '.xpi');
const id = [...crxId].map((b) => String.fromCharCode(97 + (b >> 4)) + String.fromCharCode(97 + (b & 15))).join('');
console.log('তৈরি:', base + '.crx |', base + '.zip |', base + '.xpi', '\nExtension ID:', id);
