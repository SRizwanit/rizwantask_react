import './lib/themeInit.js';   // থিম/PWA — রেন্ডারের আগে
import { EXT } from './lib/nav.js';

async function boot() {
  await import('./lib/common.js');   // window.App (পুরনো পেইজ-লজিকের জন্য) + অফলাইন/ধীর-নেট বার
  const [{ createRoot }, { default: App }] = await Promise.all([import('react-dom/client'), import('./App.jsx')]);
  createRoot(document.getElementById('root')).render(<App />);
}

if (EXT) {
  import('./lib/extSetup.js').then((m) => { if (m.needsSetup()) m.renderSetup(); else boot(); });
} else boot();
