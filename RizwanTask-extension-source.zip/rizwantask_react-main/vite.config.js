import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import fs from 'node:fs';

/* দুই ধরনের বিল্ড:
   • সাধারণ ওয়েব (npm run build)      → dist/  (GitHub Pages; VITE_BASE: "/রিপো-নাম/" বা "/")
   • ব্রাউজার এক্সটেনশন (npm run build:ext) → dist-extension/  (Manifest V3, Chrome + Firefox/Gecko, HashRouter)
   এক্সটেনশন মোডে PWA-র manifest.json/sw.js বাদ যায়; extension/ ফোল্ডারের manifest.json, background.js, icons/ ঢোকে। */
export default defineConfig(({ mode }) => {
  const ext = mode === 'extension';
  return {
    base: ext ? './' : (process.env.VITE_BASE || '/'),
    publicDir: ext ? 'extension' : 'public',
    build: {
      chunkSizeWarningLimit: 900,
      outDir: ext ? 'dist-extension' : 'dist',
      modulePreload: ext ? { polyfill: false } : true
    },
    plugins: [
      react(),
      ext && {
        name: 'kp-extension',
        transformIndexHtml: (html) => html.replace(/<link rel="manifest"[^>]*>\s*/, ''),   // PWA-র manifest এক্সটেনশনের manifest.json-এর সাথে গোলমাল করে
        closeBundle() {   // ওয়েব অ্যাপের ফন্ট ও আইকন (public/) এক্সটেনশনেও
          fs.cpSync('public/fonts', 'dist-extension/fonts', { recursive: true });
          fs.copyFileSync('public/icon.svg', 'dist-extension/icon.svg');
          fs.mkdirSync('dist-extension/icons', { recursive: true });
          for (const f of ['icon-192.png', 'icon-512.png']) fs.copyFileSync('public/icons/' + f, 'dist-extension/icons/' + f);
        }
      }
    ].filter(Boolean)
  };
});
