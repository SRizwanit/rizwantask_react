/* RizwanTask এক্সটেনশন ব্যাকগ্রাউন্ড: টুলবার আইকনে চাপলে অ্যাপ (index.html) নতুন ট্যাবে খোলে; খোলা থাকলে সেই ট্যাবেই যায়।
   Chrome (service_worker) ও Firefox/Gecko (scripts) — দুই ইঞ্জিনেই একই ফাইল। */
const api = typeof browser !== 'undefined' ? browser : chrome;
const APP = api.runtime.getURL('index.html');

api.action.onClicked.addListener(async () => {
  try {
    const tabs = await api.tabs.query({});
    const open = tabs.find((t) => t.url && t.url.startsWith(APP));
    if (open) { await api.tabs.update(open.id, { active: true }); if (open.windowId != null) await api.windows.update(open.windowId, { focused: true }); return; }
  } catch (e) { /* tabs অনুমতি ছাড়া url নাও আসতে পারে — নিচে নতুন ট্যাব */ }
  api.tabs.create({ url: APP });
});
